package net.sf.cglib.beans;

public class SampleGetter {

    int foo;

    public int getFoo() {
        return foo;
    }
}
